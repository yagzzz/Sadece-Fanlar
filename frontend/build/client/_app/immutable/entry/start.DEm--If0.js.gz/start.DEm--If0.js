import{l as o,a as r}from"../chunks/k2PWlTdl.js";export{o as load_css,r as start};
